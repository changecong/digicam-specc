#ifndef _ReadBmp_aux_h
#define _ReadBmp_aux_h

#include "digicam.sh"



#endif

